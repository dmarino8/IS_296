export interface ICustomerReview {
    id: string,
    productDescription: string,
    reviewComments: string,
    contactPhone: string,
    contactEmail: string,
    actionNeeded: boolean
}
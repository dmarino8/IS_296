package marino.tacobusinessfun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoBusinessFunApplication {

	public static void main(String[] args) {
		SpringApplication.run(TacoBusinessFunApplication.class, args);
	}

}

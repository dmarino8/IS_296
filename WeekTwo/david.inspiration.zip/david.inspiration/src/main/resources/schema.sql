create table if not exists siteviews (
    id int not null auto_increment,
    message varchar(25) not null
);
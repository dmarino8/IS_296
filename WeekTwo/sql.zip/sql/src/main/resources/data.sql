insert into products (id_pk, product_name, product_type)
values
(1, 'amazing michigan corn', 'corn');
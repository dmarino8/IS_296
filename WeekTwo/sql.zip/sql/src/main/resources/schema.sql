create table if not exists products (
id_pk int not null,
product_name varchar(25) not null,
product_type varchar(10) not null
);